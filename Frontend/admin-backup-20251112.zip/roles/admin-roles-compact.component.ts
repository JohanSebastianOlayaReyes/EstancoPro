import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { RolService } from '../../../core/services/rol.service';
import { ButtonComponent } from '../../../shared/components/button.component';
import { InputComponent } from '../../../shared/components/input.component';
import { EstancoCardComponent } from '../../../shared/components/estanco-card.component';
// AppHeaderComponent removed - not present in shared/components
import { RolDto } from '../../../core/models/rol.model';

@Component({
  selector: 'app-admin-roles',
  standalone: true,
  imports: [CommonModule, ButtonComponent, InputComponent, EstancoCardComponent],
  template: `
    <div class="page-container">
      <div class="page-content">
        <div class="section-title">
          <h1>Gestión de Roles</h1>
          <app-button variant="primary" (clicked)="toggleForm()">{{ showForm() ? 'Cancelar' : '+ Nuevo Rol' }}</app-button>
        </div>
        <!-- template preserved from original compact file -->
      </div>
    </div>
  `,
  styles: [``]
})
export class AdminRolesCompactComponent implements OnInit {
  private authService = inject(AuthService);
  private rolService = inject(RolService);
  private router = inject(Router);

  roles = signal<RolDto[]>([]);
  showForm = signal(false);
  editingId = signal<number | null>(null);
  loading = signal(false);
  error = signal('');
  success = signal('');
  form = signal<RolDto>({ typeRol: '', description: '', active: true });

  ngOnInit() { this.loadRoles(); }
  private loadRoles() { /* preserved from original */ }
  updateForm(key: string, value: any) { /* preserved */ }
  toggleForm() { /* preserved */ }
  cancelForm() { /* preserved */ }
  editRol(rol: RolDto) { /* preserved */ }
  saveRol(e: Event) { /* preserved */ }
  deleteRol(id: number) { /* preserved */ }
  logout() { this.authService.logout(); this.router.navigate(['/login']); }
}
